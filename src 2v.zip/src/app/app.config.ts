import { ApplicationConfig } from '@angular/core';
import {provideRouter, withRouterConfig} from '@angular/router';
import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { appHttpInterceptor } from './interceptors/app-http.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes , withRouterConfig({
      onSameUrlNavigation: 'reload'
    })),
    provideHttpClient(
      withInterceptors([appHttpInterceptor])
    )
  ]
};




// import { ApplicationConfig } from '@angular/core';
// import { provideRouter } from '@angular/router';
//
// import { routes } from './app.routes'; // Vos routes doivent être importées ici
// import { provideHttpClient } from '@angular/common/http';
//
// export const appConfig: ApplicationConfig = {
//   providers: [
//     provideRouter(routes), // <--- CETTE LIGNE EST CRUCIALE
//     provideHttpClient()
//   ]
// };
