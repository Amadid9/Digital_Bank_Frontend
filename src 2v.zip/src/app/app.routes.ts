import { Routes } from '@angular/router';
import { ClientsComponent } from './clients/clients';
import { ComptesComponent } from './comptes/comptes';
import { NouveauCompteComponent } from './nouveau-compte/nouveau-compte';
import { OperationsComponent } from './operations/operations';
import {LoginComponent} from './login/login.component';
import {NouveauClientComponent} from './nouveau-client/nouveau-client';
import {EditClientComponent} from './edit-client/edit-client';
import {DashboardComponent} from './dashboard/dashboard';
// import { NouveauClientComponent } from './nouveau-client/nouveau-client.component'; // Si vous l'avez

export const routes: Routes = [
  { path: 'login', component: LoginComponent },

  { path: '', redirectTo: '/login', pathMatch: 'full' },

  { path: 'clients', component: ClientsComponent },

  { path: 'comptes', component: ComptesComponent },

  { path: 'nouveau-compte', component: NouveauCompteComponent },

  { path: 'nouveau-client', component: NouveauClientComponent },

  { path: 'operations', component: OperationsComponent },

  { path: 'clients/edit/:id', component: EditClientComponent  },

  { path: 'dashboard',component: DashboardComponent  }

];
