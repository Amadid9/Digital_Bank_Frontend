import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ClientService } from '../services/client.service';
// import { Client } from '../model/client';
import { Client } from '../services/client.service';

@Component({
  selector: 'app-clients',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './clients.html',
  styleUrls: ['./clients.css']
})
export class ClientsComponent implements OnInit {

  clients: any[] = [];
  keyword: string = '';
  errorMessage: string = '';
  loading: boolean = false;

  constructor(
    private clientService: ClientService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.handleGetClients();
  }

  handleNewClient() {
    this.router.navigateByUrl('/nouveau-client');
  }

  handleGetClients() {
    this.clientService.getClients().subscribe({
      next: (data) => {
        this.clients = [...data];   // 🔥 ضروري
        this.cdr.detectChanges();   // 🔥 حل المشكل
      },
      error: (err) => {
        this.errorMessage = err.message;
      }
    });
  }

  handleDeleteClient(c: Client) {
    if (!confirm("Êtes-vous sûr de vouloir supprimer " + c.nom + " ?")) return;
    if (c.id === undefined) return;

    this.clientService.deleteClient(c.id).subscribe({
      next: () => {
        this.clients = this.clients.filter(client => client.id !== c.id);
        this.cdr.detectChanges();
      },
      error: () => {
        alert("Erreur lors de la suppression.");
      }
    });
  }

  handleSearchClients() {
    if (this.keyword === '') {
      this.handleGetClients();
      return;
    }

    this.clientService.searchClients(this.keyword).subscribe({
      next: (data) => {
        this.clients = [...data];
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }



  handleSearch() {
    console.log("Recherche avec :", this.keyword);
    // هنا دير call للservice ديال البحث
  }

}

// import {Component, OnInit, inject, ChangeDetectorRef} from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { HttpClient } from '@angular/common/http';
// import { ClientService, Client } from '../services/client.service';
// import { FormsModule } from '@angular/forms';
// import {NavigationEnd, Router, RouterLink} from '@angular/router';
// import {filter} from 'rxjs'; // Import du Router
//
// @Component({
//   selector: 'app-clients',
//   standalone: true,
//   imports: [CommonModule, FormsModule, RouterLink],
//   templateUrl: './clients.html',
//   styleUrls: ['./clients.css']
// })
// export class ClientsComponent implements OnInit {
//   // Injection des services
//   private clientService = inject(ClientService);
//   private router = inject(Router);
//
//   clients: Client[] = [];
//   errorMessage: string = '';
//   keyword: string = '';
//   loading: boolean = false;
//
//   constructor(
//     private clientService: ClientService,
//     private router: Router,
//     private cdr: ChangeDetectorRef
//   ) {}
//
//   /*  constructor() {
//       this.router.events
//         .pipe(filter(event => event instanceof NavigationEnd))
//         .subscribe(() => {
//           this.handleGetClients();
//         });
//     }*/
//
//   ngOnInit(): void {
//     this.handleGetClients();
//   }
//
//   // --- METHODE POUR LE BOUTON "NOUVEAU CLIENT" ---
//   handleNewClient() {
//     // Cela force Angular à aller sur la page /new-client
//     this.router.navigateByUrl('/nouveau-client');
//   }
//   //  *** new ***
//   handleGetClients() {
//     this.clientService.getClients().subscribe({
//       next: (data) => {
//         this.clients = [...data];   // 🔥 مهم
//         this.cdr.detectChanges();   // 🔥 يجبر Angular يحدّث الواجهة
//       },
//       error: (err) => {
//         this.errorMessage = err.message;
//       }
//     });
//   }
//
//   // handleGetClients() {
//   //   this.clientService.getClients().subscribe({
//   //     next: (data) => {
//   //       this.clients = [...data];   // 🔥 مهم
//   //       this.cdr.detectChanges();   // 🔥 يجبر Angular يحدّث الواجهة
//   //     },
//   //     error: (err) => {
//   //       this.errorMessage = err.message;
//   //     }
//   //   });
//
//
//   /*handleGetClients() {
//     this.loading = true;
//
//     this.clientService.getClients().subscribe({
//       next: (data) => {
//         this.clients = data;
//         this.loading = false;
//       },
//       error: (err) => {
//         this.errorMessage = err.message;
//         this.loading = false;
//       }
//     });
//   }*/
//
//   // handleGetClients() {
//   //   this.clientService.getClients().subscribe({
//   //     next: (data) => {
//   //       this.clients = data;
//   //     },
//   //     error: (err) => {
//   //       this.errorMessage = err.message;
//   //     }
//   //   });
//   // }
//
//   handleDeleteClient(c: Client) {
//     if (!confirm("Êtes-vous sûr de vouloir supprimer " + c.nom + " ?")) return;
//     if (c.id === undefined) return;
//
//     this.clientService.deleteClient(c.id).subscribe({
//       next: (resp) => {
//         this.clients = this.clients.filter(client => client.id !== c.id);
//       },
//       error: (err) => {
//         alert("Erreur lors de la suppression.");
//       }
//     });
//   }
// handleSearchClients() {
//   if (this.keyword === '') {
//
//     this.handleGetClients();
//     return;
//   }
//
//   this.clientService.searchClients(this.keyword).subscribe({
//     next: (data) => {
//       this.clients = [...data];  // 🔥
//       this.cdr.detectChanges();  // 🔥
//     },
//     error: (err) => console.error(err)
//   });
// }
//
//
//
//
//
//
//
//
//
//
//
//
//
//



















// handleSearchClients() {
  //   if (this.keyword.trim() === '') {
  //     this.handleGetClients();
  //     return;
  //   }
  //
  //   this.loading = true;
  //   this.clientService.searchClients(this.keyword).subscribe({
  //     next: (data) => {
  //       this.clients = data;
  //       this.loading = false;
  //     },
  //     error: () => this.loading = false
  //   });
  // }

  // handleSearchClients() {
  //   if(this.keyword === "") {
  //     this.handleGetClients();
  //     return;
  //   }
  //   this.clientService.searchClients(this.keyword).subscribe({
  //     next: (data) => this.clients = data,
  //     error: (err) => console.error(err)
  //   });
  // }







// import { Component, OnInit, inject } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { HttpClient } from '@angular/common/http';
// import { ClientService, Client } from '../services/client.service';
// import { FormsModule } from '@angular/forms'; // Nécessaire pour la recherche (ngModel)
//
// @Component({
//   selector: 'app-clients',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   templateUrl: './clients.html',
//   styleUrls: ['./clients.css']
// })
// export class ClientsComponent implements OnInit {
//   private clientService = inject(ClientService);
//
//   clients: Client[] = [];
//   errorMessage: string = '';
//   keyword: string = ''; // Pour la barre de recherche
//
//   ngOnInit(): void {
//     this.handleGetClients();
//   }
//
//   handleGetClients() {
//     this.clientService.getClients().subscribe({
//       next: (data) => {
//         this.clients = data;
//       },
//       error: (err) => {
//         this.errorMessage = err.message;
//         console.error(err);
//       }
//     });
//   }
//
//   handleDeleteClient(c: Client) {
//     if (!confirm("Êtes-vous sûr de vouloir supprimer " + c.nom + " ?")) return;
//
//     // Vérification de l'ID pour éviter les erreurs TypeScript
//     if (c.id === undefined) return;
//
//     this.clientService.deleteClient(c.id).subscribe({
//       next: (resp) => {
//         // Mise à jour de la liste locale (plus rapide que de recharger du serveur)
//         this.clients = this.clients.filter(client => client.id !== c.id);
//         alert("Client supprimé avec succès");
//       },
//       error: (err) => {
//         console.error(err);
//         alert("Erreur lors de la suppression. Vérifiez que le client n'a pas de comptes liés.");
//       }
//     });
//   }
//
//   handleSearchClients() {
//     if(this.keyword === "") {
//       this.handleGetClients();
//       return;
//     }
//
//     // Si vous avez implémenté 'searchClients' dans le service (voir ma réponse précédente)
//     this.clientService.searchClients(this.keyword).subscribe({
//       next: (data) => this.clients = data,
//       error: (err) => console.error(err)
//     });
//   }
// }

// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { RouterModule } from '@angular/router'; // <--- 1. IMPORT IMPORTANT
// import {Client, ClientService} from '../services/client.service';
//
// @Component({
//   selector: 'app-clients',
//   standalone: true,
//   // 👇 2. AJOUTEZ RouterModule ICI pour que les liens fonctionnent
//   imports: [CommonModule, RouterModule],
//   templateUrl: './clients.html', // Vérifiez si c'est clients.html ou clients.component.html
//   styleUrls: ['./clients.css']
// })
// export class ClientsComponent implements OnInit {
//
//   // clients: any;
//   clients: Client[]= [];
//   errorMessage!: string;
//
//   constructor(private clientService: ClientService) { }
//
//   ngOnInit(): void {
//     // Le chargement se fait dès l'ouverture de la page
//     this.handleSearchClients();
//   }
//
//   handleSearchClients() {
//     this.clientService.getClients().subscribe({
//       next: (data: any) => {
//         this.clients = data;
//       },
//       error: (err: any) => {
//         this.errorMessage = err.message;
//       }
//     });
//   }
//
//   // Extrait de ce à quoi devrait ressembler la méthode de suppression
//   handleDeleteClient(c: Client) {
//     // Vérification de sécurité si l'ID est undefined
//     if(!c.id) return;
//
//     let conf = confirm("Êtes-vous sûr de vouloir supprimer ce client ?");
//     if(!conf) return;
//
//     this.clientService.deleteClient(c.id).subscribe({
//       next: (resp) => {
//         // Supprimer le client de la liste locale pour rafraichir l'affichage
//         // this.clients = this.clients.filter(client => client.id !== c.id);
//         this.clients = this.clients.filter((client: Client) => client.id !== c.id);
//       },
//       error: (err) => {
//         console.log(err);
//       }
//     });
//   }

  // handleDeleteClient(c: any) {
  //   if(!confirm("Êtes-vous sûr ?")) return;
  //   this.clientService.deleteClient(c.id).subscribe({
  //     next: () => {
  //       this.handleSearchClients();
  //     },
  //     error: (err: any) => {
  //       console.log(err);
  //     }
  //   });
  // }

