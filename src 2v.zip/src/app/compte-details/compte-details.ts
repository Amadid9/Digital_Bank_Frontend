import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router'; // Pour lire l'URL

@Component({
  selector: 'app-compte-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './compte-details.html',
  styleUrl: './compte-details.css'
})
export class CompteDetailsComponent implements OnInit {

  accountId: string | null = '';
  accountBalance: number = 12500; // Solde fictif

  // Liste des opérations (Débit = Sortie, Crédit = Entrée)
  operations = [
    { id: 1, date: '2024-03-12', type: 'DEBIT', description: 'Paiement Amazon', amount: -450 },
    { id: 2, date: '2024-03-10', type: 'CREDIT', description: 'Virement Salaire', amount: 8500 },
    { id: 3, date: '2024-03-08', type: 'DEBIT', description: 'Retrait Guichet', amount: -200 },
    { id: 4, date: '2024-03-05', type: 'DEBIT', description: 'Facture Electricité', amount: -350 },
    { id: 5, date: '2024-02-28', type: 'CREDIT', description: 'Remboursement', amount: 120 }
  ];

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    // On récupère l'ID passé dans l'URL
    this.accountId = this.route.snapshot.paramMap.get('id');
  }
}
