import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart, registerables } from 'chart.js';
import { ClientService } from '../services/client.service';
import { CompteService } from '../services/compte.service';

Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class DashboardComponent implements OnInit {

  totalClients = 0;
  totalComptes = 0;
  totalSolde = 0;

  clients: any[] = [];
  comptes: any[] = [];

  constructor(
    private clientService: ClientService,
    private compteService: CompteService
  ) {}

  ngOnInit(): void {
    this.loadStats();
  }

  loadStats() {
    this.clientService.getClients().subscribe(clients => {
      this.clients = clients;
      this.totalClients = clients.length;
      this.createClientsCompteChart();
    });

    this.compteService.getComptes().subscribe(comptes => {
      this.comptes = comptes;
      this.totalComptes = comptes.length;
      this.totalSolde = comptes.reduce((sum: any, c: { solde: any; }) => sum + (c.solde || 0), 0);

      this.createTypeCompteChart();
      this.createStatutCompteChart();
      this.createSoldeTypeChart();
      this.createSoldeDistributionChart();
    });
  }

  // 📊 Pie – Type de compte
  createTypeCompteChart() {
    const courant = this.comptes.filter(c => c.type === 'COURANT').length;
    const epargne = this.comptes.filter(c => c.type === 'EPARGNE').length;

    new Chart('typeCompteChart', {
      type: 'pie',
      data: {
        labels: ['Courant', 'Épargne'],
        datasets: [{
          data: [courant, epargne]
        }]
      }
    });
  }

  // 📊 Bar – Statut compte
  createStatutCompteChart() {
    const activated = this.comptes.filter(c => c.statut === 'ACTIVATED').length;
    const suspended = this.comptes.filter(c => c.statut === 'SUSPENDED').length;
    const created = this.comptes.filter(c => c.statut === 'CREATED').length;

    new Chart('statutCompteChart', {
      type: 'bar',
      data: {
        labels: ['Activé', 'Suspendu', 'Créé'],
        datasets: [{
          label: 'Comptes',
          data: [activated, suspended, created]
        }]
      }
    });
  }

  // 📊 Bar – Solde par type
  createSoldeTypeChart() {
    const soldeCourant = this.comptes
      .filter(c => c.type === 'COURANT')
      .reduce((s, c) => s + c.solde, 0);

    const soldeEpargne = this.comptes
      .filter(c => c.type === 'EPARGNE')
      .reduce((s, c) => s + c.solde, 0);

    new Chart('soldeTypeChart', {
      type: 'bar',
      data: {
        labels: ['Courant', 'Épargne'],
        datasets: [{
          label: 'Solde (DH)',
          data: [soldeCourant, soldeEpargne]
        }]
      }
    });
  }

  // 📊 Doughnut – Répartition du solde
  createSoldeDistributionChart() {
    const low = this.comptes.filter(c => c.solde < 5000).length;
    const mid = this.comptes.filter(c => c.solde >= 5000 && c.solde < 20000).length;
    const high = this.comptes.filter(c => c.solde >= 20000).length;

    new Chart('soldeDistributionChart', {
      type: 'doughnut',
      data: {
        labels: ['< 5k', '5k - 20k', '> 20k'],
        datasets: [{
          data: [low, mid, high]
        }]
      }
    });
  }

  // 📊 Bar – Comptes par client
  createClientsCompteChart() {
    const withCompte = this.clients.filter(c => c.comptes?.length > 0).length;
    const withoutCompte = this.clients.length - withCompte;

    new Chart('clientsCompteChart', {
      type: 'bar',
      data: {
        labels: ['Avec compte', 'Sans compte'],
        datasets: [{
          label: 'Clients',
          data: [withCompte, withoutCompte]
        }]
      }
    });
  }
}


// import { Component, OnInit, inject } from '@angular/core';
// import { CommonModule } from '@angular/common';
//
// import { ClientService } from '../services/client.service';
// import { CompteService } from '../services/compte.service';
//
// @Component({
//   selector: 'app-dashboard',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './dashboard.html',
//   styleUrl: './dashboard.css'
// })
// export class DashboardComponent implements OnInit {
//
//   private clientService = inject(ClientService);
//   private compteService = inject(CompteService);
//
//   totalClients: number = 0;
//   totalComptes: number = 0;
//   totalSolde: number = 0;
//
//   ngOnInit(): void {
//     this.loadClients();
//     this.loadComptes();
//   }
//
//   // ===== CLIENTS =====
//   loadClients() {
//     this.clientService.getClients().subscribe({
//       next: (clients) => {
//         this.totalClients = clients.length;
//       },
//       error: (err) => console.error(err)
//     });
//   }
//
//   // ===== COMPTES + SOLDE =====
//   loadComptes() {
//     this.compteService.getComptes().subscribe({
//       next: (comptes: any[]) => {
//         this.totalComptes = comptes.length;
//
//         this.totalSolde = comptes.reduce(
//           (sum, c) => sum + (c.solde || 0),
//           0
//         );
//       },
//       error: (err) => console.error(err)
//     });
//   }
// }


// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common'; // <--- INDISPENSABLE
//
// @Component({
//   selector: 'app-dashboard',
//   standalone: true,
//   imports: [CommonModule], // <--- C'est ici que ça corrige l'erreur du pipe number
//   templateUrl: './dashboard.html', // Vérifiez que le nom correspond bien à votre fichier html
//   styleUrl: './dashboard.css'
// })
// export class DashboardComponent {
//   totalClients: number = 124;
//   totalComptes: number = 350;
//   totalSolde: number = 854000;
// }
