import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ClientService } from '../services/client.service';

@Component({
  selector: 'app-edit-client',
  standalone: true, // ✅ مهم بزاف
  templateUrl: './edit-client.html',
  styleUrls: ['./edit-client.css'],
  imports: [
    CommonModule,        // ✅ باش يخدم *ngIf و *ngFor
    ReactiveFormsModule
  ]
})
export class EditClientComponent implements OnInit {

  clientForm!: FormGroup;
  clientId!: number;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private clientService: ClientService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.clientId = Number(this.route.snapshot.paramMap.get('id'));

    this.clientForm = this.fb.group({
      nom: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });

    this.clientService.getClientById(this.clientId).subscribe({
      next: (client) => {
        this.clientForm.patchValue(client);
      },
      error: () => {
        this.errorMessage = 'Client introuvable';
      }
    });
  }

  handleUpdateClient() {
    if (this.clientForm.invalid) return;

    this.clientService.updateClient(this.clientId, this.clientForm.value)
      .subscribe({
        next: () => {
          this.successMessage = 'Client modifié avec succès';
          setTimeout(() => {
            this.router.navigate(['/clients']);
          }, 1000);
        },
        error: () => {
          this.errorMessage = 'Erreur lors de la modification';
        }
      });
  }
}




// import { Component, OnInit } from '@angular/core';
// import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
// import { ActivatedRoute, Router } from '@angular/router';
// import { ClientService, Client } from '../services/client.service';
//
// @Component({
//   selector: 'app-edit-client',
//   templateUrl: './edit-client.html',
//   imports: [
//     ReactiveFormsModule
//   ],
//   styleUrls: ['./edit-client.css']
// })
// export class EditClientComponent implements OnInit {
//
//   clientForm!: FormGroup;
//   clientId!: number;
//   errorMessage = '';
//   successMessage = '';
//
//   constructor(
//     private fb: FormBuilder,
//     private clientService: ClientService,
//     private route: ActivatedRoute,
//     private router: Router
//   ) {}
//
//   ngOnInit(): void {
//     // 🔹 récupérer ID depuis l'URL
//     this.clientId = Number(this.route.snapshot.paramMap.get('id'));
//
//     // 🔹 init form
//     this.clientForm = this.fb.group({
//       nom: ['', Validators.required],
//       email: ['', [Validators.required, Validators.email]]
//     });
//
//     // 🔹 charger le client pour remplir le formulaire
//     this.clientService.getClientById(this.clientId).subscribe({
//       next: (client) => {
//         this.clientForm.patchValue(client);
//       },
//       error: () => {
//         this.errorMessage = 'Client introuvable';
//       }
//     });
//   }
//
//   handleUpdateClient() {
//     if (this.clientForm.invalid) return;
//
//     this.clientService.updateClient(this.clientId, this.clientForm.value)
//       .subscribe({
//         next: () => {
//           this.successMessage = 'Client modifié avec succès';
//           setTimeout(() => {
//             this.router.navigate(['/clients']);
//           }, 1000);
//         },
//         error: () => {
//           this.errorMessage = 'Erreur lors de la modification';
//         }
//       });
//   }
// }
