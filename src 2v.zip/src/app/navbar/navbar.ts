import { Component, inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import {Router, RouterLink, RouterLinkActive} from '@angular/router'; // RouterLink pour les liens HTML

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive], // Nécessaire pour routerLink="..."
  templateUrl: './navbar.html',
  styleUrls: ['./navbar.css']
})
export class NavbarComponent {
  public authService = inject(AuthService);
  private router = inject(Router);
  public username: string= '';

  ngOnInit(): void {
    this.username = localStorage.getItem('username') || 'Utilisateur';
  }
  go(url: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigateByUrl(url);
    });
  }

  handleLogout() {
    this.authService.logout();
    // Le service redirige déjà, mais on peut forcer ici si besoin
    this.router.navigateByUrl('/login');
  }
}

// import { Component } from '@angular/core';
// import { RouterLink, RouterLinkActive } from '@angular/router'; // Imports essentiels
// import { CommonModule } from '@angular/common';
//
// @Component({
//   selector: 'app-navbar',
//   standalone: true,
//   imports: [CommonModule, RouterLink, RouterLinkActive], // On ajoute RouterLinkActive pour le style
//   templateUrl: './navbar.html',
//   styleUrl: './navbar.css'
// })
// export class NavbarComponent {
//   // Pas de logique complexe pour l'instant
// }
