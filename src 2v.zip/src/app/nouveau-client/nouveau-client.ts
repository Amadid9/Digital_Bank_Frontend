import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Client, ClientService } from '../services/client.service';

@Component({
  selector: 'app-new-client',
  standalone: true,
  // Imports essentiels : ReactiveFormsModule pour le formulaire, RouterLink pour le bouton retour
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './nouveau-client.html',
  styleUrls: ['./nouveau-client.css']
})
export class NouveauClientComponent {

  private fb = inject(FormBuilder);
  private clientService = inject(ClientService);
  private router = inject(Router);

  errorMessage: string = '';

  // Formulaire strict (Nom + Email uniquement, comme sur le PDF)
  clientForm: FormGroup = this.fb.group({
    nom: ['', [Validators.required, Validators.minLength(4)]],
    email: ['', [Validators.required, Validators.email]]
  });

  handleSaveClient() {
    // 1. On arrête si le formulaire est invalide
    if (this.clientForm.invalid) {
      this.errorMessage = "Veuillez remplir les champs obligatoires.";
      return;
    }

    const newClient: Client = this.clientForm.value;

    // 2. Appel au service
    this.clientService.addClient(newClient).subscribe({
      next: (data) => {
        // SUCCÈS : On retourne à la liste
        alert("Client ajouté avec succès !");
        this.router.navigateByUrl('/clients');
      },
      error: (err) => {
        // ERREUR : On affiche le problème
        console.error(err);
        if (err.status === 403) {
          this.errorMessage = "Accès refusé (403). Vérifiez que CSRF est désactivé dans le Backend.";
        } else if (err.status === 401) {
          this.errorMessage = "Session expirée. Veuillez vous reconnecter.";
        } else {
          this.errorMessage = "Erreur technique. Le backend est-il lancé ?";
        }
      }
    });
  }
}

// import { Component, inject } from '@angular/core';
// import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { Router, RouterLink } from '@angular/router'; // Import de RouterLink pour le bouton Annuler
// import { CommonModule } from '@angular/common';
// import { Client, ClientService } from '../services/client.service';
//
// @Component({
//   selector: 'app-new-client',
//   standalone: true,
//   // IMPORTANT : On importe ReactiveFormsModule pour le formulaire
//   // et RouterLink pour pouvoir utiliser le lien "Annuler"
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: '/nouveau-client.html',
//   styleUrls: ['./nouveau-client.css']
// })
// export class NouveauClientComponent {
//
//   private fb = inject(FormBuilder);
//   private clientService = inject(ClientService);
//   private router = inject(Router);
//
//   errorMessage: string = '';
//
//   clientForm: FormGroup = this.fb.group({
//     nom: ['', [Validators.required, Validators.minLength(3)]],
//     email: ['', [Validators.required, Validators.email]]
//   });
//
//   onSubmit() {
//     if (this.clientForm.invalid) return;
//
//     const clientData: Client = this.clientForm.value;
//
//     this.clientService.addClient(clientData).subscribe({
//       next: () => {
//         alert("Client ajouté !");
//         this.router.navigateByUrl('/clients');
//       },
//       error: () => {
//         this.errorMessage = "Erreur lors de l'enregistrement.";
//       }
//     });
//   }
// }

// import { Component, inject } from '@angular/core';
// import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { Router, RouterLink } from '@angular/router'; // Import de RouterLink pour le bouton Annuler
// import { CommonModule } from '@angular/common';
// import { Client, ClientService } from '../services/client.service';
//
// @Component({
//   selector: 'app-new-client',
//   standalone: true,
//   // IMPORTANT : On importe ReactiveFormsModule pour le formulaire
//   // et RouterLink pour pouvoir utiliser le lien "Annuler"
//   imports: [ReactiveFormsModule, CommonModule, RouterLink],
//   templateUrl: '/nouveau-client.html',
//   styleUrls: ['./nouveau-client.css']
// })
// export class NouveauClientComponent {
//
//   // Injection des services
//   private fb = inject(FormBuilder);
//   private clientService = inject(ClientService);
//   private router = inject(Router);
//
//   errorMessage: string = '';
//
//   // Définition du formulaire
//   clientForm: FormGroup = this.fb.group({
//     nom: ['', [Validators.required, Validators.minLength(4)]],
//     email: ['', [Validators.required, Validators.email]]
//   });
//
//   // Méthode appelée lors de la soumission du formulaire
//   handleSaveClient() {
//     // 1. Vérifier si le formulaire est valide
//     if (this.clientForm.invalid) {
//       this.errorMessage = "Veuillez remplir correctement tous les champs.";
//       return;
//     }
//
//     // 2. Préparer les données
//     const newClient: Client = this.clientForm.value;
//
//     // 3. Envoyer au backend
//     this.clientService.addClient(newClient).subscribe({
//       next: (data) => {
//         alert("Client ajouté avec succès !");
//         // 4. Rediriger vers la liste des clients
//         this.router.navigateByUrl('/clients');
//       },
//       error: (err) => {
//         console.error(err);
//         // Gestion des erreurs spécifiques
//         if (err.status === 403) {
//           this.errorMessage = "Vous n'avez pas la permission d'ajouter un client.";
//         } else {
//           this.errorMessage = "Erreur lors de l'ajout (Vérifiez si le backend tourne).";
//         }
//       }
//     });
//   }
// }

// import { Component, inject } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { Router } from '@angular/router';
// import { ClientService, Client } from '../services/client.service';
//
// @Component({
//   selector: 'app-new-client',
//   standalone: true,
//   imports: [ReactiveFormsModule, CommonModule],
//   templateUrl: './nouveau-client.html',
//   styleUrls: ['./nouveau-client.css']
// })
// export class NewClientComponent {
//
//   private fb = inject(FormBuilder);
//   private clientService = inject(ClientService);
//   private router = inject(Router);
//
//   errorMessage: string = '';
//
//   // Formulaire sans le téléphone (pour respecter le PDF strict)
//   clientForm: FormGroup = this.fb.group({
//     nom: ['', [Validators.required, Validators.minLength(3)]],
//     email: ['', [Validators.required, Validators.email]]
//   });
//
//   onSubmit() {
//     if (this.clientForm.invalid) return;
//
//     const clientData: Client = this.clientForm.value;
//
//     this.clientService.addClient(clientData).subscribe({
//       next: (savedClient) => {
//         alert("Client ajouté !");
//         // Retour automatique à la liste
//         this.router.navigateByUrl('/clients');
//       },
//       error: (err) => {
//         console.error(err);
//         this.errorMessage = "Erreur lors de l'enregistrement.";
//       }
//     });
//   }
// }

/*
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client, ClientService } from '../services/client.service';

@Component({
  selector: 'app-new-client',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule], // Nécessaire pour [formGroup] et *ngIf
  templateUrl: './nouveau-client.html',
  styleUrls: ['./nouveau-client.css'] // Attention: c'est souvent 'styleUrl' ou 'styleUrls' selon la version
})
export class NewClientComponent {


  private fb = inject(FormBuilder);
  private clientService = inject(ClientService);
  private router = inject(Router);


  errorMessage: string = '';


  clientForm: FormGroup = this.fb.group({
    nom: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    // Note: Si votre entité Backend "Client" (PDF page 2) n'a pas de champ téléphone,
    // assurez-vous que le backend l'ignore ou ajoutez-le dans votre classe Java.
    telephone: ['', Validators.required]
  });

  // 4. La méthode appelée lors du click sur "Enregistrer"
  onSubmit() {
    // A. Vérification basique coté frontend
    if (this.clientForm.invalid) {
      this.errorMessage = "Veuillez remplir correctement tous les champs obligatoires.";
      return;
    }

    // B. Préparation des données
    const clientData: Client = this.clientForm.value;

    // C. Appel au Backend via le Service
    this.clientService.addClient(clientData).subscribe({
      next: (savedClient) => {
        console.log('Succès:', savedClient);
        alert("Client ajouté avec succès !");

        // D. Redirection vers la liste des clients après succès
        this.router.navigateByUrl('/clients');
      },
      error: (err) => {
        console.error('Erreur Backend:', err);
        // Gestion fine de l'erreur pour l'utilisateur
        if (err.status === 403) {
          this.errorMessage = "Vous n'avez pas les droits pour ajouter un client.";
        } else if (err.status === 400) {
          this.errorMessage = "Données invalides. Vérifiez l'email (il existe peut-être déjà).";
        } else {
          this.errorMessage = "Une erreur est survenue lors de l'enregistrement. Vérifiez que le serveur est lancé.";
        }
      }
    });
  }
}
*/



// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { Router } from '@angular/router';
// import { CommonModule } from '@angular/common';
// import { ClientService } from '../services/client.service'; // Import du service créé
//
// @Component({
//   selector: 'app-nouveau-client',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule],
//   templateUrl: './nouveau-client.html', // Attention au nom du fichier HTML
//   styleUrl: './nouveau-client.css'
// })
// export class NouveauClientComponent implements OnInit {
//
//   newCustomerFormGroup!: FormGroup;
//   errorMessage!: string;
//
//   constructor(
//     private fb: FormBuilder,
//     private clientService: ClientService, // Injection du service
//     private router: Router
//   ) { }
//
//   ngOnInit(): void {
//     // On crée le formulaire avec les noms EXACTS du Backend
//     this.newCustomerFormGroup = this.fb.group({
//       nom: ['', Validators.required],   // C'est bien 'nom' ?
//       email: ['', [Validators.required, Validators.email]] // C'est bien 'email' ?
//     });
//   }
//
//   handleSaveClient() {
//     let client = this.newCustomerFormGroup.value;
//
//     // Appel au backend
//     this.clientService.saveClient(client).subscribe({
//       next: (data) => {
//         alert("Client enregistré avec succès !");
//         // Redirection vers la liste des clients (vérifiez que la route est '/clients')
//         this.router.navigateByUrl('/clients');
//       },
//       error: (err) => {
//         console.error(err);
//         this.errorMessage = "Impossible d'enregistrer le client. Vérifiez le serveur.";
//       }
//     });
//   }
// }


