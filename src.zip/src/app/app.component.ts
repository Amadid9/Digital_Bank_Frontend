import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common'; // Important pour *ngIf
import { Router, RouterOutlet } from '@angular/router';
import { NavbarComponent } from './navbar/navbar';
import {routes} from './app.routes';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // constructor(public router: Router) {}
  public router = inject(Router);
  // protected readonly routes = routes;
}
