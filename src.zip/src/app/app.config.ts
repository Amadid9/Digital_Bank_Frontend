import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes'; // Vos routes doivent être importées ici
import { provideHttpClient } from '@angular/common/http';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes), // <--- CETTE LIGNE EST CRUCIALE
    provideHttpClient()
  ]
};
