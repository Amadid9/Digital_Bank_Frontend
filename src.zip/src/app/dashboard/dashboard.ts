import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // <--- INDISPENSABLE

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule], // <--- C'est ici que ça corrige l'erreur du pipe number
  templateUrl: './dashboard.html', // Vérifiez que le nom correspond bien à votre fichier html
  styleUrl: './dashboard.css'
})
export class DashboardComponent {
  totalClients: number = 124;
  totalComptes: number = 350;
  totalSolde: number = 854000;
}
