import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  errorMessage: string = '';

  loginForm: FormGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
  });

  handleLogin() {
    if (this.loginForm.invalid) return;

    const { username, password } = this.loginForm.value;

    this.authService.login(username, password).subscribe({
      next: (data) => {
        // Redirection après succès (vers /clients ou /admin)
        this.router.navigateByUrl('/clients');
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = "Identifiants incorrects ou problème de serveur.";
      }
    });
  }
}



// import { Component } from '@angular/core';
// import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { Router } from '@angular/router';
// import { CommonModule } from '@angular/common';
//
// // Assurez-vous que le chemin vers votre service est correct
// import { AuthService } from '../services/auth.service';
//
// @Component({
//   selector: 'app-login',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule],
//   templateUrl: './login.component.html',
//   styleUrl: './login.component.css'
// })
// export class LoginComponent {
//
//   loginForm: FormGroup;
//   errorMessage: string = '';
//
//   constructor(
//     private fb: FormBuilder,
//     private authService: AuthService,
//     private router: Router
//   ) {
//     // Initialisation du formulaire
//     this.loginForm = this.fb.group({
//       // "username" correspond exactement au champ dans votre AuthRequest.java
//       username: ['', Validators.required],
//       password: ['', Validators.required]
//     });
//   }
//
//   handleLogin() {
//     // On réinitialise le message d'erreur
//     this.errorMessage = '';
//
//     if (this.loginForm.valid) {
//       // Appel au service d'authentification
//       this.authService.login(this.loginForm.value).subscribe({
//
//         next: (data) => {
//           // SUCCÈS : Le backend a renvoyé { "token": "..." }
//           // On sauvegarde le token
//           this.authService.saveToken(data.token);
//
//           // On redirige l'utilisateur vers la page des comptes
//           this.router.navigateByUrl('/comptes');
//         },
//
//         error: (err) => {
//           // ERREUR : Affichage d'un message selon le problème
//           console.error(err);
//           if (err.status === 401 || err.status === 403) {
//             this.errorMessage = "Identifiant ou mot de passe incorrect.";
//           } else {
//             this.errorMessage = "Une erreur est survenue. Serveur inaccessible ?";
//           }
//         }
//       });
//     } else {
//       // Si l'utilisateur clique sans rien remplir
//       this.errorMessage = "Veuillez remplir tous les champs.";
//     }
//   }
// }
