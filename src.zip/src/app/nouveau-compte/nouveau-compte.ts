import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {Client, ClientService} from '../services/client.service';
import { CompteService } from '../services/compte.service';

@Component({
  selector: 'app-nouveau-compte',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './nouveau-compte.html',
  styleUrls: ['./nouveau-compte.css']
})
export class NouveauCompteComponent implements OnInit {

  accountFormGroup!: FormGroup;
  // clients: any; // Pour la liste déroulante
  clients: Client[] = []; // Pour la liste déroulante

  constructor(private fb: FormBuilder,
              private clientService: ClientService,
              private compteService: CompteService,
              private router: Router) { }

  ngOnInit(): void {
    // 1. On initialise le formulaire
    this.accountFormGroup = this.fb.group({
      clientId: [null, Validators.required], // L'ID du client est obligatoire
      balance: [0, [Validators.required, Validators.min(100)]], // Solde initial
      type: ['Courant', Validators.required], // Par défaut Compte Courant
      overDraft: [0], // Découvert (pour courant)
      interestRate: [0] // Taux (pour épargne)
    });

    // 2. On charge la liste des clients pour le <select>
    this.clientService.getClients().subscribe({
      next: (data: any) => {
        this.clients = data;
        console.log("Clients chargés :", data);
      },
      error: (err: any) => {
        console.log("Erreur chargement clients :", err);
      }
    });
  }

  handleSaveAccount() {
    let accountInfo = this.accountFormGroup.value;

    this.compteService.saveAccount(accountInfo).subscribe({
      // 👇 Ajoutez ": any" après data
      next: (data: any) => {
        alert("Compte créé avec succès !");
        this.router.navigateByUrl("/comptes");
      },
      // 👇 Ajoutez ": any" après err
      error: (err: any) => {
        console.log(err);
        alert("Erreur lors de la création du compte");
      }
    });
  }
}
