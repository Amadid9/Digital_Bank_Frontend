import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);

  // URL de votre Backend sur le port 8085
  // private BASE_URL = 'http://localhost:8085';
  private BASE_URL = 'http://localhost:8085/api/auth';


  constructor() { }

  // 1. Méthode de Login
  public login(username: string, password: string): Observable<any> {
    // Adaptez '/login' selon votre backend (ex: '/auth/login', '/api/login')
    return this.http.post<any>(`${this.BASE_URL}/login`, { username, password })
      .pipe(
        tap(response => {
          // Supposons que le backend renvoie un objet json avec le token
          // Ex: { "accessToken": "eyJhbG..." } ou directement le token
          // // ADAPTEZ 'access-token' selon le nom exact renvoyé par votre API Java
          // if (response && response['access-token']) {
          //   this.saveToken(response['access-token']);
          // }
          if (response && response.token) {
            this.saveToken(response.token);
          }

        })
      );
  }

  // 2. Sauvegarder le token
  public saveToken(token: string): void {
    localStorage.setItem('jwt-token', token);
  }

  // 3. Récupérer le token
  public getToken(): string | null {
    return localStorage.getItem('jwt-token');
  }

  // 4. Se déconnecter
  public logout(): void {
    localStorage.removeItem('jwt-token');
    this.router.navigateByUrl('/login');
  }

  // 5. Vérifier si l'utilisateur est connecté (basique)
  public isAuthenticated(): boolean {
    const token = this.getToken();
    // Idéalement, il faut aussi vérifier l'expiration du token (avec jwt-decode)
    return !!token;
  }
}

// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { jwtDecode } from 'jwt-decode'; // Assurez-vous d'avoir fait : npm install jwt-decode
//
// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//
//   // URL exacte basée sur votre AuthController
//   private apiUrl = 'http://localhost:8085/api/auth/login';
//
//   constructor(private http: HttpClient) { }
//
//   // Connexion
//   public login(credentials: any): Observable<any> {
//     return this.http.post(this.apiUrl, credentials);
//   }
//
//   // Sauvegarder le token
//   public saveToken(token: string): void {
//     localStorage.setItem('token', token); // On garde la clé 'token' simple
//   }
//
//   // Récupérer le token (utilisé par l'intercepteur)
//   public getToken(): string | null {
//     return localStorage.getItem('token');
//   }
//
//   // Vérifier si connecté (token présent et non expiré)
//   public isAuthenticated(): boolean {
//     const token = this.getToken();
//     if (!token) return false;
//
//     try {
//       const decoded: any = jwtDecode(token);
//       const currentTime = Date.now() / 1000;
//       return decoded.exp > currentTime; // Vérifie la date d'expiration
//     } catch (e) {
//       return false; // Si le token est corrompu
//     }
//   }
//
//   // Récupérer le nom de l'utilisateur (username)
//   public getUsername(): string | null {
//     const token = this.getToken();
//     if (token) {
//       const decoded: any = jwtDecode(token);
//       return decoded.sub; // Spring met souvent le username dans 'sub'
//     }
//     return null;
//   }
//
//   public logout(): void {
//     localStorage.removeItem('token');
//   }
// }
