import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface correspondant à l'entité Client du PDF (page 2) [cite: 32, 33]
export interface Client {
  id?: number; // Optionnel car absent lors de la création
  nom: string;
  email: string;
}
@Injectable({
  providedIn: 'root'
})
export class ClientService {

  private http = inject(HttpClient);

  // ✅ نفس الbase ديال auth
  private apiServerUrl = 'http://localhost:8085/api';

  public addClient(client: Client): Observable<Client> {
    return this.http.post<Client>(`${this.apiServerUrl}/clients`, client);
  }

  public getClients(): Observable<Client[]> {
    return this.http.get<Client[]>(`${this.apiServerUrl}/clients`);
  }

  public deleteClient(clientId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/clients/${clientId}`);
  }

  public searchClients(keyword: string): Observable<Client[]> {
    return this.http.get<Client[]>(
      `${this.apiServerUrl}/clients/search?keyword=${keyword}`
    );
  }
}





//
// @Injectable({
//   providedIn: 'root'
// })
// export class ClientService {
//   private http = inject(HttpClient);
//   // Adaptez le port si votre backend n'est pas sur 8080
//   // private apiServerUrl = 'http://localhost:8085';
//   private apiServerUrl = 'http://localhost:8085/api';
//
//   // 1. AJOUTER UN CLIENT (Déjà présent)
//   public addClient(client: Client): Observable<Client> {
//     return this.http.post<Client>(`${this.apiServerUrl}/clients`, client);
//   }
//
//   // 2. RÉCUPÉRER LES CLIENTS (C'est ce qui manquait pour l'erreur 'getClients')
//   public getClients(): Observable<Client[]> {
//     return this.http.get<Client[]>(`${this.apiServerUrl}/clients`);
//   }
//
//   // 3. SUPPRIMER UN CLIENT (C'est ce qui manquait pour l'erreur 'deleteClient')
//   public deleteClient(clientId: number): Observable<void> {
//     return this.http.delete<void>(`${this.apiServerUrl}/clients/${clientId}`);
//   }
//
//   // 4. RECHERCHER DES CLIENTS (Bonus : utile pour la "recherche" mentionnée dans le PDF [cite: 55])
//   public searchClients(keyword: string): Observable<Client[]> {
//     return this.http.get<Client[]>(`${this.apiServerUrl}/clients/search?keyword=${keyword}`);
//   }
// }










// import { Injectable, inject } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
//
//
// const API_URL = 'http://localhost:8085/api/clients';
//
// export interface Client {
//   nom: string;
//   email: string;
// }
//
// @Injectable({
//   providedIn: 'root'
// })
// export class ClientService {
//   private http = inject(HttpClient);
//   addClient(client: Client): Observable<any> {
//     return this.http.post(API_URL, client);
//   }
// }
