import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompteService {

  private backendHost = "http://localhost:8085";
  constructor(private http: HttpClient) { }

  public getComptes(): Observable<any> {
    return this.http.get(this.backendHost + "/comptes");
  }

  public saveAccount(account: any): Observable<any> {
    return this.http.post(this.backendHost + "/comptes", account);
  }

  public getAccount(accountId: string, page: number, size: number): Observable<any> {
    return this.http.get(this.backendHost + "/comptes/" + accountId + "/pageOperations?page=" + page + "&size=" + size);
  }


  public debit(accountId: string, amount: number, description: string): Observable<any> {
    let data = { accountId: accountId, amount: amount, description: description };
    return this.http.post(this.backendHost + "/comptes/debit", data);
  }


  public credit(accountId: string, amount: number, description: string): Observable<any> {
    let data = { accountId: accountId, amount: amount, description: description };
    return this.http.post(this.backendHost + "/comptes/credit", data);
  }


  public transfer(accountSource: string, accountDestination: string, amount: number, description: string): Observable<any> {
    let data = { accountSource, accountDestination, amount, description };
    return this.http.post(this.backendHost + "/comptes/virement", data);
  }
}
